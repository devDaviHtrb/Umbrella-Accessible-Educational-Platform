import { DefaultTheme, ThemeProvider } from "expo-router/react-navigation";
import { useFonts } from 'expo-font';
import {
  Lexend_400Regular,
  Lexend_500Medium,
  Lexend_600SemiBold,
  Lexend_700Bold,
} from '@expo-google-fonts/lexend';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import 'react-native-reanimated';

import { AppearanceRoot } from '@/components/layout/appearance-root';
import { Colors } from '@/constants/theme';
import { AuthProvider } from '@/hooks/api/auth/authContext';
import { PreferencesProvider } from '@/hooks/preferences/preferencesContext';

SplashScreen.preventAutoHideAsync();

export const unstable_settings = {
  anchor: 'login',
};

const UmbrellaNavigationTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: Colors.light.primary,
    background: Colors.light.background,
    card: Colors.light.surface,
    text: Colors.light.text,
    border: Colors.light.outline,
  },
};

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    Lexend_400Regular,
    Lexend_500Medium,
    Lexend_600SemiBold,
    Lexend_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <ThemeProvider value={UmbrellaNavigationTheme}>
      <PreferencesProvider>
        <AuthProvider>
          <AppearanceRoot>
            <Stack>
              <Stack.Screen name="login" options={{ headerShown: false }} />
              <Stack.Screen name="signUp" options={{ headerShown: false }} />
              <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
              <Stack.Screen name="professor" options={{ headerShown: false }} />
            </Stack>
          </AppearanceRoot>
          <StatusBar style="dark" />
        </AuthProvider>
      </PreferencesProvider>
    </ThemeProvider>
  );
}
