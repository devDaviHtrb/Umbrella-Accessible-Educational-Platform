import { router } from 'expo-router';
import { StyleSheet } from 'react-native';

import { CourseForm } from '@/components/professor/course-form';
import { LoadError } from '@/components/professor/load-error';
import { ScreenContainer } from '@/components/layout/screen-container';
import { UmbrellaText } from '@/components/ui/umbrella-text';
import { professorRoutes } from '@/constants/routes';
import { Colors, Spacing } from '@/constants/theme';
import { confirmDestructive, notify } from '@/utils/confirm';
import { useProfessorCourses } from '@/hooks/api/professor/useProfessorCourses';
import { useFocusData } from '@/hooks/use-focus-data';
import { useSubmit } from '@/hooks/use-submit';
import type { ProfessorCourseInput } from '@/types/professor';

export default function NewCourseScreen() {
  const { getCategories, createCategory, deleteCategory, createCourse } = useProfessorCourses();
  const { data: categories, loading, error: loadError, reload, retry } = useFocusData(getCategories);

  async function handleCreateCategory(name: string) {
    const created = await createCategory(name);
    await reload();
    return created.id;
  }

  function handleDeleteCategory(id: string) {
    const category = categories?.find((item) => item.id === id);
    confirmDestructive({
      title: 'Excluir categoria',
      message: `A categoria "${category?.label ?? ''}" será excluída e os cursos que a usam ficarão sem categoria.`,
      onConfirm: async () => {
        try {
          await deleteCategory(id);
          await reload();
        } catch {
          notify('Não foi possível excluir', 'Tente novamente em instantes.');
        }
      },
    });
  }

  const { submit, submitting, error } = useSubmit(
    async (input: ProfessorCourseInput) => {
      const createdId = await createCourse(input);
      if (createdId) {
        router.replace(professorRoutes.course(createdId));
      } else {
        router.dismissTo(professorRoutes.home);
      }
    },
    { errorMessage: 'Não foi possível criar o curso. Tente novamente.' },
  );

  return (
    <ScreenContainer disableTopInset contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <UmbrellaText variant="body" color={Colors.light.textSecondary}>
        Preencha os dados básicos. Depois de criar o curso você poderá adicionar módulos e atividades.
      </UmbrellaText>

      {loading ? (
        <UmbrellaText variant="body" color={Colors.light.textSecondary}>
          Carregando categorias...
        </UmbrellaText>
      ) : loadError && !categories ? (
        <LoadError message="Não foi possível carregar as categorias." onRetry={retry} />
      ) : categories ? (
        <CourseForm
          categories={categories}
          onCreateCategory={handleCreateCategory}
          onDeleteCategory={handleDeleteCategory}
          submitLabel="Criar Curso"
          submitting={submitting}
          submitError={error}
          onSubmit={submit}
        />
      ) : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingTop: Spacing.lg,
  },
});
